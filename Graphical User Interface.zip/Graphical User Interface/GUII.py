import os
import textwrap
import cv2
import numpy as np
from PIL import Image, ImageTk
import customtkinter as ctk
from tkinter import filedialog

from keras.saving.save import load_model
from matplotlib.font_manager import FontProperties
from matplotlib import image as mpimg, pyplot as plt

import cv2
from termcolor import cprint
import os
from keras.applications import ResNet101
import keras.utils as image
from keras.applications.densenet import preprocess_input
from keras import Model
from warnings import simplefilter
from diffusers import StableDiffusionPipeline
simplefilter(action='ignore', category=DeprecationWarning)
# pipe = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4")

import time
import os
from PIL import Image, ImageTk, ImageOps
import customtkinter as ctk
from tkinter import filedialog
import torch


class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.cap = None
        self.filename = None
        self.title("Image Generation")
        self.geometry("600x500")

        # Initialize the text-to-image pipeline
        # self.pipe = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4")
        # self.pipe.to("cuda" if torch.cuda.is_available() else "cpu")
        #
        # Set grid layout
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # Load images
        image_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "Demo_FileImages")
        self.logo_image = ctk.CTkImage(Image.open(os.path.join(image_path, "logo_single.jpg")), size=(26, 26))

        # Navigation frame
        self.navigation_frame = ctk.CTkFrame(self, corner_radius=0)
        self.navigation_frame.grid(row=0, column=0, sticky="nsew")
        self.navigation_frame.grid_rowconfigure(9, weight=1)

        self.navigation_frame_label = ctk.CTkLabel(self.navigation_frame, text="<< STEPS >>", compound="left",
                                                   font=("Arial", 14, "bold"))
        self.navigation_frame_label.grid(row=0, column=0, padx=30, pady=20)

        # Label
        self.action_label = ctk.CTkLabel(self.navigation_frame, text="Choose any one action",
                                         font=("Arial", 14, "bold"))
        self.action_label.grid(row=1, column=0, columnspan=2, pady=(10, 20))  # Spans across both columns

        # Buttons
        self.home_button = ctk.CTkButton(self.navigation_frame, text="Select Image", command=self.frame_1)
        self.home_button.grid(row=2, column=0, padx=10, pady=10)  # Reduced width with horizontal padding

        self.text_button = ctk.CTkButton(self.navigation_frame, text="Text", command=self.frame_2)
        self.text_button.grid(row=2, column=1, padx=10, pady=10)  # Adjust padding similarly

        self.gen_button = ctk.CTkButton(self.navigation_frame, text="Generation", command=self.Prediction)
        self.gen_button.grid(row=3, columnspan=2, padx=10, pady=10)  # Centered with smaller width

        self.refresh_button = ctk.CTkButton(self.navigation_frame, text="Refresh", command=self.Refresh_Action)
        self.refresh_button.grid(row=4, columnspan=2, padx=10, pady=10)  # Adjust as needed

        self.exit_button = ctk.CTkButton(self.navigation_frame, text="Exit", command=self.Destroy_Action)
        self.exit_button.grid(row=5, columnspan=2, padx=10, pady=10)  # Centered button

        # Set appearance mode
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")

        # Home frame
        self.home_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.home_frame.grid_columnconfigure(0, weight=1)

    def frame_1(self):
        # File dialog to select an image
        self.filename = filedialog.askopenfilename(initialdir="Datasets/Flickr8k/Images", title="Select an Image File",
                                                   filetypes=(("Image Files", "*.jpg *.png *.jpeg"), ("All Files", "*.*")))

        if self.filename:
            image1 = Image.open(self.filename)
            self.type = 'image'
            # Convert to grayscale
            self.grayscale_image = ImageOps.grayscale(image1)
            self.grayscale_image.thumbnail((200, 200))  # Resize for display

            # Set hover effect
            self.home_button.configure(fg_color="green")

            self.select_frame_by_name("home")

            self.image_display = ctk.CTkLabel(self.home_frame, image=ctk.CTkImage(image1, size=(200, 200)),
                                              text="Original Image", compound='top')
            self.image_display.grid(row=0, column=0, padx=50, pady=10, sticky="w")


    def frame_2(self):
        self.type = 'text'
        # Input text field for image generation prompt
        self.prompt_label = ctk.CTkLabel(self.home_frame, text="Enter Prompt:", font=ctk.CTkFont(size=14))
        self.prompt_label.grid(row=1, column=0, padx=10, pady=10)

        self.prompt_entry = ctk.CTkEntry(self.home_frame, width=300)
        self.prompt_entry.grid(row=2, column=0, padx=10, pady=10)

    def Prediction11(self):

        if self.type == 'image':
            import time
            time.sleep(10)

            self.gray_display = ctk.CTkLabel(self.home_frame, image=ctk.CTkImage(self.grayscale_image, size=(200, 200)), text="")
            self.gray_display.grid(row=1, column=0, padx=50, pady=10, sticky="w")

        else:

            # Generate image based on the text prompt
            prompt = self.prompt_entry.get() if hasattr(self, 'prompt_entry') else None
            if not prompt:
                ctk.CTkLabel(self.home_frame, text="No prompt provided!", fg_color="red").grid(row=3, column=0, padx=10,
                                                                                               pady=10)
                return

            ctk.CTkLabel(self.home_frame, text="Generating image...").grid(row=4, column=0, padx=10, pady=10)
            self.update()

            # Generate image using the model
            generated_image = self.pipe(prompt, num_inference_steps=10).images[0]
            generated_image = generated_image.resize((300, 300))

            # Display the generated image
            self.generated_image_ctk = ctk.CTkImage(generated_image)
            self.generated_label = ctk.CTkLabel(self.home_frame, image=self.generated_image_ctk, text="")
            self.generated_label.grid(row=5, column=0, padx=10, pady=10)

    # Function to generate image with loader
    def Prediction(self):
        if self.type == 'image':
            # Simulate image processing
            progress = ctk.CTkProgressBar(self.home_frame, mode='indeterminate', width=200, fg_color='green')
            progress.grid(row=5, column=0, padx=10, pady=10)
            progress.start()

            self.update_idletasks()
            time.sleep(10)  # Simulate processing time
            progress.stop()
            progress.destroy()

            # Display grayscale image
            self.gray_display = ctk.CTkLabel(self.home_frame, image=ctk.CTkImage(self.grayscale_image, size=(200, 200)),
                                             text="Generated Image", compound='top')
            self.gray_display.grid(row=1, column=0, padx=50, pady=10, sticky="w")

        else:
            # Generate image based on text prompt
            prompt = self.prompt_entry.get() if hasattr(self, 'prompt_entry') else None
            if not prompt:
                ctk.CTkLabel(self.home_frame, text="No prompt provided!", fg_color="red").grid(row=3, column=0, padx=10,
                                                                                               pady=10)
                return

            # Show progress bar while generating image
            progress = ctk.CTkProgressBar(self.home_frame, mode='indeterminate', width=200, fg_color="green")
            progress.grid(row=5, column=0, columnspan=2, padx=10, pady=10, sticky='ew')
            progress.start()
            self.update_idletasks()

            # Simulate model inference delay
            time.sleep(5)  # Replace with actual model call, e.g., self.pipe(...)
            progress.stop()
            progress.destroy()

            # Generate image using the model (dummy placeholder code for your pipe)
            generated_image = Image.new("RGB", (300, 300), "blue")  # Placeholder image
            generated_image = generated_image.resize((300, 300))

            # Display the generated image
            self.generated_image_ctk = ctk.CTkImage(generated_image)
            self.generated_label = ctk.CTkLabel(self.home_frame, image=self.generated_image_ctk,
                                                text="Generated Image", compound='top')
            self.generated_label.grid(row=1, column=0, padx=10, pady=10)

    def Refresh_Action(self):
        for widget in self.home_frame.winfo_children():
            widget.destroy()

    def Destroy_Action(self):
        self.destroy()

    def select_frame_by_name(self, name):
        self.home_frame.grid(row=0, column=1, sticky="nsew")


if __name__ == "__main__":
    app = App()
    app.mainloop()
